



<?php
include 'db.php';
if (isset($_POST['login'])) {
	$password=mysqli_real_escape_string($con,$_POST['code']);
		
	$retrieved ="SELECT * FROM james WHERE  code ='$password'";
	$result = mysqli_query($con,$retrieved);
	$retrieved2 ="SELECT * FROM angel WHERE code ='$password'";
	$result2 = mysqli_query($con,$retrieved2);


	if (mysqli_num_rows($result)) {
		header("Location:johndashboard.php");
	}elseif(mysqli_num_rows($result2)){
		header("Location:angeldashboard.php");
	}
	else{
		echo "Invalid pin";
	}


