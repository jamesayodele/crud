



<?php
include "db.php";
if (isset($_POST['login'])) {
  $code =mysqli_real_escape_string($con,$_POST['code']);
 // $password =mysqli_real_escape_string($connection,$_POST['password']);
  $query ="SELECT * FROM adminlogin WHERE password ='$code' ";
  $select =mysqli_query($con,$query);
  if(mysqli_num_rows($select) > 0){

   header("Location:adminActivities.php");
  }else{

    ?>
<p id="error" style="background-color:red;color:white;">Invalid password</p>

    <?php
    //echo "Invalid password";
  }
  
}

?>

<!DOCTYPE html>
<html>
<head>
  <title>report</title>
  <style type="text/css">
  html, body {
  align-items: center;
  background: #f2f4f8;
  border: 0;
  display: flex;
  font-family: Helvetica, Arial, sans-serif;
  font-size: 16px;
  height: 100%;
  justify-content: center;
  margin: 0;
  padding: 0;
}


textarea{
  width:500px;
  height:100px;
  border-radius:5px solid #f2f4f8;
}
#hq{
background-color:blue;
color:white;
height:40px;

}
#display{
  position:absolute;
  left:500px;
  border:4px solid red;
  height:30px;
  width:400px;
  top:100px;
  text-align:center;

}

#back{
  background-color:blue;
color:white;
height:40px;
}
.mainbody{
  position: relative;
}

#error{
   position:absolute;
  text-align:center;
  border:1px solid red;
  height:30px;
  width:120px;
  top:10px;
  
}
  </style>



  




  


</head>
<body>
<div class="mainbody">

 <form method="post" action="adminLogin.php" id="login-form" >
  
   
      <input type="password" name="code" placeholder="please enter password"><br><br>
       
        <input type="submit" name="login" value="ADMIN LOGIN" id="hq"><br><br>
         <a href="index.php" style="text-decoration:none;text-transform: 
         capitalize;"><p>go to home page</p></a>
      
</form>


</div>
</body>
</html>