<!Doctype html>  
<Html>     
<Head>      
<Title>     
only for the admin 
</Title>  
<style>  
.dropbtn {  
    background-color: yellow;  
    color: black;  
    padding: 10px;  
    font-size: 12px;  
}  
.dropdown {  
    display: inline-block;  
    position: relative  
}  
.dropdown-content {  
    position: absolute;  
    background-color: lightgrey;  
    min-width: 200px;  
    display: none;  
    z-index: 1;  
}  
.dropdown-content a {  
    color: black;  
    padding: 12px 16px;  
    text-decoration: none;  
    display: block;  
}  
.dropdown-content a:hover {  
    background-color: orange;  
}  
.dropdown:hover .dropdown-content {  
    display: block;  
}  
.dropdown:hover .dropbtn {  
    background-color: grey;  
}  
.dropdown{
    left: 500px;
}
picture{
    top:40px;
    left:500px;
    width:200px;
    height: 100px;
    position:absolute;
    border:5px solid green;
}
</style>  
</Head>  
<Body>   


<picture>
  <img src="admin2.png" height="100%" width="100%">
</picture>
 <br><br><br><br><br> <br><br><br><br>
<div class="dropdown">  
<button class="dropbtn"> ADMIN ACTIVITIES,CLICK ME </button>  
<div class="dropdown-content">  
<a href="loginenterclass.php">Enter Classes</a> 
<a href="uploadNewsletter.php">Upload Newsletter</a>  
<a href="printvalidPin.php">Print Valid Pins</a>


 
<a href="index.php">Login Out</a>  




</div>  
</div>  
</Body>   
</Html>  