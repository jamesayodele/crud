





<?php
include 'db.php';

if (isset($_POST['delete'])) {
	     $id= mysqli_real_escape_string($con,$_POST['id']);

  
      $deleteRow ="DELETE FROM john WHERE id ='$id' ";
      $resultDeleted =mysqli_query($con,$deleteRow);
     if ($resultDeleted) {
     	echo "record successfuly deleted";
     }
}

?>



<!DOCTYPE html>
<html>
<head>
	<title>Delete Records</title>
</head>
<body>
<form action="deletejohnResult.php" method="post">
		<input type="text" name="id" placeholder="please enter your id"><br>

	
						<input type="submit" name="delete" value="DELETE RECORD">

			




</form><br><br>
<a href="editjohnRecord.php">Go Back</a>
</body>
</html>