
<?php
include "db.php";
if (isset($_POST['upload'])) {
  $fullName =mysqli_real_escape_string($con,$_POST['fullName']);
    $code =mysqli_real_escape_string($con,$_POST['code']);
        $date =mysqli_real_escape_string($con,$_POST['date']);



  $fileName = $_FILES['file']['name'];
  $fileTmpName = $_FILES['file']['tmp_name'];
  $path = "files/".$fileName;
  if ($path) {
    # code...

    move_uploaded_file($fileTmpName, $path);
    $sql = "INSERT INTO john (fullName,fileName,code,date) VALUES ('$fullName','$fileName','$code','$date')";
    $run =mysqli_query($con,$sql);
    echo "sucess";
  }
}


?>



<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<form action="editjohnRecord.php" method="post" enctype="multipart/form-data">
  <input type="file" name="file"><br>
  <input type="text" name="fullName" placeholder="Please enter full name">
  <input type="text" name="code" value="<?php echo uniqid('',false);  ?>" readonly>
    <input type="date" name="date">



  <input type="submit" name="upload" value="UPLOAD RESULT">
<br><br>

  <!--<a href="deletejohnResult.php"  target="_blank">DELETE RECORD</a><br>-->
    <!--<a href=""  target="_blank">AUTHORIZE ACCESS</a><br>-->
      <a href="viewjohnrecords.php"  target="_blank">VIEW RECORD</a>


    


      


</form>
<a href="john.php">Go back</a>


<!--<a href="download.php?file=<?php //echo urlencode($row['filename']); ?>">Download</a>-->
</body>
</html>

