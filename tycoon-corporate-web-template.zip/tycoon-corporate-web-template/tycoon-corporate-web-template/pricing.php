<!DOCTYPE html>
<html lang="en">
<head>
 <?php

   include "header.php";


   

if (isset($_POST['login'])) {

	include "db.php";

	$password=mysqli_real_escape_string($con,$_POST['code']);
		
	$retrieved ="SELECT * FROM john WHERE  code ='$password'";
	$result = mysqli_query($con,$retrieved);
	$retrieved2 ="SELECT * FROM angel WHERE code ='$password'";
	$result2 = mysqli_query($con,$retrieved2);


	if (mysqli_num_rows($result) > 0) {
		header("Location:johndashboard.php");
	}elseif (mysqli_num_rows($result2) > 0) {
	    header("Location:angeldashboard.php");

	}else{
		echo "Invalid pin";
	}

}

    ?>
</head>
<body>


<?php
include"header2.php";

?>








	<section id="inner-headline">
	<div class="container">
	
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">RESULT CHECKER</h2>
			</div>
		</div>
	</div>
	</section>





<br><br>
<div class="container">
	<div class="row">
		<div class="col-lg-6 col-md-6">
			
		</div>
		<div class="col-lg-6 col-md-6">

			<form  action="pricing.php" method="post"  id="login-form" >
  
   
      <input type="password" name="code" placeholder="please enter pin"><br>
       
        <input type="submit" name="login" value="CHECK RESULT" id="hq"><br><br>
         <a href="index.php" style="text-decoration:none;text-transform: 
         capitalize;"><p>go to home page</p></a>
      
</form>
			
		</div>
	</div>
</div>

 







	<!--<section id="content">
	<div class="container">	 
		<div class="row"> 
							<div class="col-md-12">
								<div class="about-logo">
									<h3>Voluptatem Accusantium Doloremque</h3>
									<p>Sed ut perspiciaatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas</p>
                                    	<p>Sed ut perspiciaatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas</p>
								</div>  
							</div>
						</div>
		
		<div class="row">
			<div class="col-lg-12"> 
			</div>
			<div class="col-md-3 col-sm-3">
				<div class="pricing-box-item">
					<div class="pricing-heading">
						<h3><strong>Basic</strong></h3>
					</div>
					<div class="pricing-terms">
						<h6>&#36;15.00 / Year</h6>
					</div>
					<div class="pricing-container">
						<ul>
							<li><i class="icon-ok"></i> Responsive Design</li>
							<li><i class="icon-ok"></i> Bootstrap Design</li>
							<li><i class="icon-ok"></i> Unlimited Support</li>
							<li><i class="icon-ok"></i> Free Trial version</li>
							<li><i class="icon-ok"></i> HTML5 CSS3 jQuery</li>
						</ul>
					</div>
					<div class="pricing-action">
						<a href="#" class="btn btn-medium"><i class="icon-bolt"></i> Get Now</a>
					</div>
				</div>
			</div>
			<div class="col-md-3 col-sm-3">
				<div class="pricing-box-item">
					<div class="pricing-heading">
						<h3><strong>Standard</strong></h3>
					</div>
					<div class="pricing-terms">
						<h6>&#36;20.00 / Year</h6>
					</div>
					<div class="pricing-container">
						<ul>
							<li><i class="icon-ok"></i> Responsive Design</li>
							<li><i class="icon-ok"></i> Bootstrap Design</li>
							<li><i class="icon-ok"></i> Unlimited Support</li>
							<li><i class="icon-ok"></i> Free Trial version</li>
							<li><i class="icon-ok"></i> HTML5 CSS3 jQuery</li>
						</ul>
					</div>
					<div class="pricing-action">
						<a href="#" class="btn btn-medium"><i class="icon-bolt"></i> Get Now</a>
					</div>
				</div>
			</div>
			<div class="col-md-3 col-sm-3">
				<div class="pricing-box-item activeItem">
					<div class="pricing-heading">
						<h3><strong>Advanced</strong></h3>
					</div>
					<div class="pricing-terms">
						<h6>&#36;15.00 / Year</h6>
					</div>
					<div class="pricing-container">
						<ul>
							<li><i class="icon-ok"></i> Responsive Design</li>
							<li><i class="icon-ok"></i> Bootstrap Design</li>
							<li><i class="icon-ok"></i> Unlimited Support</li>
							<li><i class="icon-ok"></i> Free Trial version</li>
							<li><i class="icon-ok"></i> HTML5 CSS3 jQuery</li>
						</ul>
					</div>
					<div class="pricing-action">
						<a href="#" class="btn btn-medium"><i class="icon-bolt"></i> Get Now</a>
					</div>
				</div>
			</div>
			<div class="col-md-3 col-sm-3">
				<div class="pricing-box-item">
					<div class="pricing-heading">
						<h3><strong>Mighty</strong></h3>
					</div>
					<div class="pricing-terms">
						<h6>&#36;15.00 / Year</h6>
					</div>
					<div class="pricing-container">
						<ul>
							<li><i class="icon-ok"></i> Responsive Design</li>
							<li><i class="icon-ok"></i> Bootstrap Design</li>
							<li><i class="icon-ok"></i> Unlimited Support</li>
							<li><i class="icon-ok"></i> Free Trial version</li>
							<li><i class="icon-ok"></i> HTML5 CSS3 jQuery</li>
						</ul>
					</div>
					<div class="pricing-action">
						<a href="#" class="btn btn-medium"><i class="icon-bolt"></i> Get Now</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	</section>-->












	 <?php

   include "footer.php";
    ?>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script>  
<script src="js/jquery.flexslider.js"></script>
<script src="js/animate.js"></script>
<!-- Vendor Scripts -->
<script src="js/modernizr.custom.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>
</body>
</html>