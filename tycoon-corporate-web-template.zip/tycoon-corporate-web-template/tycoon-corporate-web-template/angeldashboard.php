<!DOCTYPE html>
<html>
<head>
<title>How to Download File using PHP/MySQLi</title>
</head>
<body>
	<h2>Congratulations, you can now check your result here</h2>
		<a href="index.php">Go home</a>

	<table border="1">
		<thead>
			<th>RESULT</th>
			<th>NEWS LETTER</th>
		</thead>
		<tbody>
		<?php
			//include('conn.php');
			include "db.php";
			include "download.php";
			$query=mysqli_query($con,"SELECT * FROM newsletter");
			$query2=mysqli_query($con,"SELECT * FROM angel");
			$row2=mysqli_fetch_array($query2);
			while($row=mysqli_fetch_array($query)){
				?>
					<tr>
				<td><a href="download.php?file=<?php echo $row2['fileName']; ?>">Download Result</a></td>
				<td><a href="download.php?file=<?php echo $row['filename']; ?>">Download Newsletter</a></td>
					</tr>
				<?php
			}
		?>
		</tbody>
	</table>
</body>
</html>