<?php
define("HOST", "localhost");
define("USER", "root");
define("PASSWORD", "");
define("DBNAME", "school");
$con =mysqli_connect(HOST,USER,PASSWORD,DBNAME);

$error =mysqli_connect_error();
if (!$con) {
  echo "no db: {$error}";
}
?>