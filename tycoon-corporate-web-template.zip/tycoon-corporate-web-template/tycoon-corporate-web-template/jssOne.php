
<?php
include 'db.php';
$retrieve ="SELECT * FROM  john";
$result =mysqli_query($con,$retrieve);


?>


<!Doctype html>  
<Html>     
<Head>      
<Title>     
only for the admin 
</Title>  
<style>  
.dropbtn {  
    background-color: yellow;  
    color: black;  
    padding: 10px;  
    font-size: 12px;  
}  
.dropdown {  
    display: inline-block;  
    position: relative  
}  
.dropdown-content {  
    position: absolute;  
    background-color: lightgrey;  
    min-width: 200px;  
    display: none;  
    z-index: 1;  
}  
.dropdown-content a {  
    color: black;  
    padding: 12px 16px;  
    text-decoration: none;  
    display: block;  
}  
.dropdown-content a:hover {  
    background-color: orange;  
}  
.dropdown:hover .dropdown-content {  
    display: block;  
}  
.dropdown:hover .dropbtn {  
    background-color: grey;  
}  
.dropdown{
    left: 500px;
}
picture{
    top:40px;
    left:500px;
    width:200px;
    height: 100px;
    position:absolute;
    border:5px solid green;
}
</style>  
</Head>  
<Body>   
<?php
$row =mysqli_fetch_array($result);
?>

<picture>
  <img src="admin2.png" height="100%" width="100%">
</picture>
 <br><br><br><br><br> <br><br><br><br>
<div class="dropdown">  
<button class="dropbtn">Junior Secondary School,JJS One</button>  
<div class="dropdown-content">  
<a href="john.php"><?php  echo $row['fullName'];  ?></a>  
<a href="angel.php">angel</a> 
 <a href="">next</a> 

<a href="adminActivities.php">Go to Admin Page</a>  




</div>  
</div>  
</Body>   
</Html>  