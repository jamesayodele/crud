<?php
include 'db.php';
$retrieve ="SELECT * FROM  john";
$result =mysqli_query($con,$retrieve);

$retrieve2 ="SELECT * FROM angel";
$result2 =mysqli_query($con,$retrieve2);
$row2 =mysqli_fetch_array($result2);

?>




<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.mainbody{
			position:relative;
		}
		form{
			top:20px;
			left:160px;
			position: absolute;
			width:600px;
			height:50px;
		}


table{
			top:120px;
			left:200px;
			position: absolute;
			height:40px;
			width:250px;
			
		}



#delete{
           top:40px;
			left:3px;
			position: absolute;
			width:140px;
			height:30px;
			background-color:green;
			color:white;
			border:5px solid green;
}

#num{
	position: absolute;
	border-radius:15px solid grey;

}
#deleteAll{
	 top:80px;
			left:3px;
			position: absolute;
			width:140px;
			height:30px;
			background-color:green;
			color:white;
			border:5px solid green;
}


th{

	background-color:black;
	color:white;
}

	</style>
</head>
<body>
	<div class="mainbody">

<a href="editjohnRecord.php"
style="text-decoration: none;
color:brown;
position:absolute;
left:2
00px;
top:70px;"><p>GO BACK </p></a><br><br>


<p><a href="#"> Print</a></p>








	<table border="1">
		<tr>
			
		
		
		
		<th>FULL NAME</th>
		
		<th>CODE</th>
		<th>DATE</th>
		
		</tr>
		<?php     
    while ($row =mysqli_fetch_array($result)) {
    	
    	?>
    	
		<tr>

			
			
        <td><?php echo $row['fullName'];  ?></td>
                
                        <td><?php echo $row['code'];  ?></td>	
                                <td><?php echo $row['date'];  ?></td>		
	
		

			
		</tr>




		<tr>

			
			
        <td><?php echo $row2['fullName'];  ?></td>
                
                        <td><?php echo $row2['code'];  ?></td>	
                                <td><?php echo $row2['date'];  ?></td>		
	
		

			
		</tr>
		<?php
        
       }
		?>
	</table>




</div>
</body>
</html>