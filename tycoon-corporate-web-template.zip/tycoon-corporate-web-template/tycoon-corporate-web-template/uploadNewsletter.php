<?php
//$conn = mysqli_connect('localhost','root','','school');
include 'db.php';
if (isset($_POST['submit'])) {
	$fileName = $_FILES['file']['name'];
	$fileTmpName = $_FILES['file']['tmp_name'];
	$path = "files/".$fileName;
	if ($path) {
		# code...

		move_uploaded_file($fileTmpName, $path);
		$sql = "INSERT INTO newsletter(filename) VALUES ('$fileName')";
		$run =mysqli_query($con,$sql);
		echo "sucess";
	}
}


?>



<?php
$retrieve ="SELECT * FROM newsletter";
$result =mysqli_query($con,$retrieve);


?>




<?php
//include 'db.php';

if (isset($_POST['delete'])) {
	     $id= mysqli_real_escape_string($con,$_POST['num']);

  
      $deleteRow ="DELETE FROM newsletter WHERE id ='$id' ";
      $resultDeleted =mysqli_query($con,$deleteRow);
     if ($resultDeleted) {
     	echo "record successfuly deleted";
     }
}

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="uploadNewsletter.php" method="post" enctype="multipart/form-data">
	<input type="number" name="num" placeholder="please enter id">
	<input type="file" name="file"><br>
	<input type="submit" name="delete" value="DELETE NEWSLATTER">
	<input type="submit" name="submit">

</form>
<a href="index.php">Go home</a>

<br><br><br>
<table border="1">
		<tr>
			
		<th>ID</th>
		
		
		
		<th>FILE NAME</th>
		
		
		
		</tr>
		<?php     
    while ($row =mysqli_fetch_array($result)) {
    	
    	?>
    	
		<tr>

						<td><?php echo $row['id']; ?></td>
			
			
        
                <td><?php echo $row['filename'];  ?></td>
                        		
	
		

			
		</tr>
		<?php
        
       }
		?>
	</table>

<!--<a href="download.php?file=<?php //echo urlencode($row['filename']); ?>">Download</a>-->
</body>
</html>
