	
<div id="wrapper" class="home-page">
<div class="topbar">
  <div class="container">
    <div class="row">
      <div class="col-md-12">     
        <p class="pull-left hidden-xs"><i class="fa fa-clock-o"></i><span>Mon - Fri  from 8am -4pm.</span></p>
        <p class="pull-right"><i class="fa fa-phone"></i>Tel No. 07051157085</p>
      </div>
    </div>
  </div>
</div>





    <!-- start header -->
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><img src="img/logo1.jpg" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="index.php">Home</a></li> 
						 <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">About Us <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                           <!--<li><a href="about.php">Company</a></li>-->
                            <li><a href="about.php">Our Team</a></li>
                            <li><a href="#">News</a></li>
                            <!--<li><a href="#">Investors</a></li>-->
                        </ul>
                    </li> 
						<!--<li><a href="services.php">Services</a></li>-->
                        <li><a href="portfolio.php">Gallery</a></li>
                        <li><a href="pricing.php">Check Result</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->